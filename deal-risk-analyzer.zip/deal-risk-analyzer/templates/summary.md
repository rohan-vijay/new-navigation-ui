# Account summary — {{account}}

**Tier:** {{tier}}  ·  **Score:** {{score}}  ·  **Owner:** {{owner}}

## Why this matters
{{rationale}}

## Recommended next step
- {{next_action}}

## Signals
{{#each signals}}
- {{this}}
{{/each}}

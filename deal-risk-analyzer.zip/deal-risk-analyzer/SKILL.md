# Deal Risk Analyzer

## Overview
Flags at-risk opportunities by analyzing stalled activity, single-threading, and slipping close dates.

## When to use
- A deal hasn’t advanced in 14+ days
- A weekly pipeline review is run

## Workflow
1. Scan open opportunities for risk signals
2. Score each deal’s health
3. Explain the top risk drivers
4. Recommend a save play

## Best practices
- Ground every recommendation in the account's own signals
- Keep outputs CRM-ready so reps can act in one click
- Reference files in /references for ICP and messaging rules

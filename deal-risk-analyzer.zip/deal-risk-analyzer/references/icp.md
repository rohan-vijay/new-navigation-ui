# Ideal Customer Profile

## Segments
- **Enterprise** — 1,000+ employees, dedicated RevOps team
- **Mid-market** — 200–1,000 employees, scaling GTM motion
- **SMB** — <200 employees, founder-led sales

## Must-have attributes
- Operates a multi-channel sales motion
- Has a CRM of record (Salesforce / HubSpot)
- Active pipeline of 20+ open opportunities

## Disqualifiers
- No revenue function
- Region outside supported markets

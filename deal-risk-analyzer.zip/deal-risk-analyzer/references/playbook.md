# Deal Risk Analyzer — Playbook

This playbook defines how the **Deal Risk Analyzer** skill should reason about
deals across the GTM funnel.

## Inputs
- Account firmographics (industry, size, region)
- Engagement signals (emails, calls, product usage)
- Pipeline stage and recent activity

## Scoring rubric
| Signal              | Weight |
| ------------------- | ------ |
| ICP fit             | 0.35   |
| Buying intent       | 0.30   |
| Champion engagement | 0.20   |
| Budget / timing     | 0.15   |

## Guardrails
- Never fabricate firmographic data — defer to enrichment.
- Flag low-confidence outputs for human review.

"""Shared helpers for GTM skills."""


def load_context(payload: dict) -> dict:
    return {
        "account": payload.get("account"),
        "signals": payload.get("signals", []),
        "stage": payload.get("stage", "discovery"),
    }


def normalize(signals: list[str]) -> dict[str, float]:
    """Map raw signal strings to a 0..1 strength per dimension."""
    buckets = {"icp_fit": 0.0, "intent": 0.0, "engagement": 0.0, "timing": 0.0}
    for s in signals:
        if "pricing" in s or "demo" in s:
            buckets["intent"] = min(1.0, buckets["intent"] + 0.5)
        if "opened" in s or "reply" in s:
            buckets["engagement"] = min(1.0, buckets["engagement"] + 0.3)
        if "renewal" in s:
            buckets["timing"] = 0.8
    buckets["icp_fit"] = 0.7
    return buckets

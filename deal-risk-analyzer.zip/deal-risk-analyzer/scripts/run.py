"""Deal Risk Analyzer — runtime entrypoint."""
from unify.sdk import skill, tool
from .utils import load_context, normalize


@skill("deal-risk")
def run(payload: dict) -> dict:
    """Execute the Deal Risk Analyzer skill against an inbound payload."""
    ctx = load_context(payload)
    signals = normalize(ctx["signals"])

    score = 0.0
    for signal, weight in WEIGHTS.items():
        score += signals.get(signal, 0) * weight

    return {
        "status": "ok",
        "account": ctx["account"],
        "score": round(score * 100),
        "tier": tier_for(score),
    }


WEIGHTS = {
    "icp_fit": 0.35,
    "intent": 0.30,
    "engagement": 0.20,
    "timing": 0.15,
}


def tier_for(score: float) -> str:
    if score >= 0.75:
        return "A"
    if score >= 0.5:
        return "B"
    return "C"
